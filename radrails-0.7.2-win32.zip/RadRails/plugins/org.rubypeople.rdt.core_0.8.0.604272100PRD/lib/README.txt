Create the jruby.jar:
1) Checkout the Branch TOM_RDT_POSITION from :pserver:anonymous@cvs.sourceforge.net:/cvsroot/jruby
2) Open JAR Packager on generateJrubyJar.jardesc, adapt the target path and create the jruby.jar file

 
