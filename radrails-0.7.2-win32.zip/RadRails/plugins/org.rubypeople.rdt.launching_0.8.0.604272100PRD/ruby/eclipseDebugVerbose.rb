module DebugVerbose
end
require 'eclipseDebug'